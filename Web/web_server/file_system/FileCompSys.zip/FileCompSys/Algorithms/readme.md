Esta carpeta contiene algoritmos de apoyo
para el sistema de compresion de archivos.

#Used for testing if file 1 == file2 prints true

#coded and maintained by zikln - rodrigoor1999@outlook.com


